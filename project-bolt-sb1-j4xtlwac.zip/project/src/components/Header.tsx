import React from 'react';
import { FileSearch, Zap } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm border-b">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <FileSearch className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">ResumeAnalyzer</h1>
              <p className="text-sm text-gray-600">AI-powered career optimization</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 py-2 rounded-lg">
            <Zap className="w-4 h-4" />
            <span className="text-sm font-medium">Pro Analysis</span>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;