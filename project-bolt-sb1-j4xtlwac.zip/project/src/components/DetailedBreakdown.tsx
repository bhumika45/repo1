import React, { useState } from 'react';
import { AnalysisData } from '../App';
import { 
  Code, 
  Briefcase, 
  GraduationCap, 
  Search, 
  ChevronDown, 
  ChevronRight,
  CheckCircle,
  XCircle,
  AlertCircle
} from 'lucide-react';

interface DetailedBreakdownProps {
  data: AnalysisData;
}

const DetailedBreakdown: React.FC<DetailedBreakdownProps> = ({ data }) => {
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    skills: true,
    experience: false,
    education: false,
    keywords: false
  });

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const sections = [
    {
      key: 'skills',
      title: 'Skills Analysis',
      icon: Code,
      score: data.sections.skills.score,
      content: (
        <div className="space-y-4">
          <div>
            <h5 className="font-medium text-green-700 mb-2 flex items-center">
              <CheckCircle className="w-4 h-4 mr-1" />
              Matched Skills ({data.sections.skills.matches.length})
            </h5>
            <div className="flex flex-wrap gap-2">
              {data.sections.skills.matches.map((skill, index) => (
                <span key={index} className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                  {skill}
                </span>
              ))}
            </div>
          </div>
          
          <div>
            <h5 className="font-medium text-red-700 mb-2 flex items-center">
              <XCircle className="w-4 h-4 mr-1" />
              Missing Skills ({data.sections.skills.missing.length})
            </h5>
            <div className="flex flex-wrap gap-2">
              {data.sections.skills.missing.map((skill, index) => (
                <span key={index} className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm">
                  {skill}
                </span>
              ))}
            </div>
          </div>
        </div>
      )
    },
    {
      key: 'experience',
      title: 'Experience Match',
      icon: Briefcase,
      score: data.sections.experience.score,
      content: (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-blue-50 p-3 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{data.sections.experience.relevantYears}</div>
              <div className="text-sm text-gray-600">Years of relevant experience</div>
            </div>
            <div className="bg-indigo-50 p-3 rounded-lg">
              <div className="text-2xl font-bold text-indigo-600">{data.sections.experience.matchingRoles.length}</div>
              <div className="text-sm text-gray-600">Matching role types</div>
            </div>
          </div>
          
          <div>
            <h5 className="font-medium text-gray-700 mb-2">Relevant Positions</h5>
            <div className="space-y-2">
              {data.sections.experience.matchingRoles.map((role, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span className="text-sm text-gray-700">{role}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )
    },
    {
      key: 'education',
      title: 'Education & Certifications',
      icon: GraduationCap,
      score: data.sections.education.score,
      content: (
        <div className="space-y-4">
          <div>
            <h5 className="font-medium text-green-700 mb-2">Relevant Education</h5>
            <div className="space-y-2">
              {data.sections.education.relevantDegrees.map((degree, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span className="text-sm text-gray-700">{degree}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div>
            <h5 className="font-medium text-blue-700 mb-2">Certifications</h5>
            <div className="space-y-2">
              {data.sections.education.certifications.map((cert, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-blue-600" />
                  <span className="text-sm text-gray-700">{cert}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )
    },
    {
      key: 'keywords',
      title: 'Keyword Optimization',
      icon: Search,
      score: data.sections.keywords.score,
      content: (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-emerald-50 p-3 rounded-lg">
              <div className="text-2xl font-bold text-emerald-600">{data.sections.keywords.matched}</div>
              <div className="text-sm text-gray-600">Keywords matched</div>
            </div>
            <div className="bg-gray-50 p-3 rounded-lg">
              <div className="text-2xl font-bold text-gray-600">{data.sections.keywords.total}</div>
              <div className="text-sm text-gray-600">Total keywords found</div>
            </div>
          </div>
          
          <div>
            <h5 className="font-medium text-yellow-700 mb-2 flex items-center">
              <AlertCircle className="w-4 h-4 mr-1" />
              Missing Keywords
            </h5>
            <div className="flex flex-wrap gap-2">
              {data.sections.keywords.missing.map((keyword, index) => (
                <span key={index} className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm">
                  {keyword}
                </span>
              ))}
            </div>
          </div>
        </div>
      )
    }
  ];

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border">
      <div className="p-6 border-b">
        <h3 className="text-lg font-semibold text-gray-900">Detailed Analysis</h3>
        <p className="text-sm text-gray-600 mt-1">Deep dive into each section of your resume</p>
      </div>
      
      <div className="divide-y">
        {sections.map((section) => {
          const Icon = section.icon;
          const isExpanded = expandedSections[section.key];
          
          return (
            <div key={section.key}>
              <button
                onClick={() => toggleSection(section.key)}
                className="w-full p-6 flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center space-x-3">
                  <Icon className="w-5 h-5 text-gray-600" />
                  <div className="text-left">
                    <h4 className="font-medium text-gray-900">{section.title}</h4>
                    <div className="flex items-center space-x-2 mt-1">
                      <span className={`text-sm font-medium ${getScoreColor(section.score)}`}>
                        {section.score}% Match
                      </span>
                      <div className="w-20 bg-gray-200 rounded-full h-1.5">
                        <div
                          className={`h-1.5 rounded-full ${
                            section.score >= 80 ? 'bg-emerald-500' :
                            section.score >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                          }`}
                          style={{ width: `${section.score}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                
                {isExpanded ? (
                  <ChevronDown className="w-5 h-5 text-gray-400" />
                ) : (
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                )}
              </button>
              
              {isExpanded && (
                <div className="px-6 pb-6">
                  {section.content}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default DetailedBreakdown;