import React from 'react';

interface ScoreCardProps {
  title: string;
  score: number;
  color: 'blue' | 'emerald' | 'indigo' | 'purple';
  description: string;
}

const ScoreCard: React.FC<ScoreCardProps> = ({ title, score, color, description }) => {
  const getColorClasses = (color: string) => {
    switch (color) {
      case 'blue':
        return {
          bg: 'bg-blue-50',
          text: 'text-blue-700',
          border: 'border-blue-200',
          accent: 'text-blue-600'
        };
      case 'emerald':
        return {
          bg: 'bg-emerald-50',
          text: 'text-emerald-700',
          border: 'border-emerald-200',
          accent: 'text-emerald-600'
        };
      case 'indigo':
        return {
          bg: 'bg-indigo-50',
          text: 'text-indigo-700',
          border: 'border-indigo-200',
          accent: 'text-indigo-600'
        };
      case 'purple':
        return {
          bg: 'bg-purple-50',
          text: 'text-purple-700',
          border: 'border-purple-200',
          accent: 'text-purple-600'
        };
      default:
        return {
          bg: 'bg-gray-50',
          text: 'text-gray-700',
          border: 'border-gray-200',
          accent: 'text-gray-600'
        };
    }
  };

  const colors = getColorClasses(color);
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className={`${colors.bg} ${colors.border} border rounded-xl p-6 transition-all hover:shadow-md`}>
      <div className="flex items-center justify-between mb-3">
        <h3 className={`font-semibold ${colors.text}`}>{title}</h3>
        <div className={`text-2xl font-bold ${getScoreColor(score)}`}>
          {score}%
        </div>
      </div>
      <p className="text-sm text-gray-600">{description}</p>
      
      <div className="mt-4">
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className={`h-2 rounded-full transition-all duration-500 ${
              score >= 80 ? 'bg-emerald-500' :
              score >= 60 ? 'bg-yellow-500' : 'bg-red-500'
            }`}
            style={{ width: `${score}%` }}
          />
        </div>
      </div>
    </div>
  );
};

export default ScoreCard;