import React from 'react';
import { Lightbulb, CheckCircle2 } from 'lucide-react';

interface SuggestionsPanelProps {
  suggestions: string[];
}

const SuggestionsPanel: React.FC<SuggestionsPanelProps> = ({ suggestions }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border p-6">
      <div className="flex items-center mb-6">
        <Lightbulb className="w-5 h-5 text-yellow-600 mr-2" />
        <h3 className="text-lg font-semibold text-gray-900">Improvement Suggestions</h3>
      </div>
      
      <div className="space-y-4">
        {suggestions.map((suggestion, index) => (
          <div key={index} className="flex items-start space-x-3 p-3 bg-yellow-50 rounded-lg border border-yellow-100">
            <CheckCircle2 className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
            <p className="text-sm text-gray-700 leading-relaxed">{suggestion}</p>
          </div>
        ))}
      </div>
      
      <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-100">
        <h4 className="font-medium text-blue-900 mb-2">Pro Tip</h4>
        <p className="text-sm text-blue-800">
          Focus on the highest-impact changes first. Adding missing keywords and quantifying achievements 
          can significantly improve your match score.
        </p>
      </div>
    </div>
  );
};

export default SuggestionsPanel;