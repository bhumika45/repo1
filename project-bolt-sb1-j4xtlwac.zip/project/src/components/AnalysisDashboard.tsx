import React from 'react';
import { AnalysisData } from '../App';
import ScoreCard from './ScoreCard';
import SuggestionsPanel from './SuggestionsPanel';
import DetailedBreakdown from './DetailedBreakdown';
import { RotateCcw, Download } from 'lucide-react';

interface AnalysisDashboardProps {
  data: AnalysisData;
  onReset: () => void;
}

const AnalysisDashboard: React.FC<AnalysisDashboardProps> = ({ data, onReset }) => {
  const handleDownload = () => {
    // Mock download functionality
    console.log('Downloading analysis report...');
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm border p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Analysis Complete</h2>
            <p className="text-gray-600">Here's how your resume matches the job requirements</p>
          </div>
          <div className="flex space-x-3">
            <button
              onClick={handleDownload}
              className="flex items-center space-x-2 px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Download Report</span>
            </button>
            <button
              onClick={onReset}
              className="flex items-center space-x-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
              <span>New Analysis</span>
            </button>
          </div>
        </div>
      </div>

      {/* Score Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <ScoreCard
          title="Overall Match"
          score={data.overallScore}
          color="blue"
          description="Resume compatibility with job requirements"
        />
        <ScoreCard
          title="Skills Match"
          score={data.sections.skills.score}
          color="emerald"
          description={`${data.sections.skills.matches.length} skills matched`}
        />
        <ScoreCard
          title="Experience"
          score={data.sections.experience.score}
          color="indigo"
          description={`${data.sections.experience.relevantYears} years relevant experience`}
        />
        <ScoreCard
          title="ATS Compatible"
          score={data.atsCompatibility}
          color="purple"
          description="Applicant Tracking System score"
        />
      </div>

      {/* Main Content */}
      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <DetailedBreakdown data={data} />
        </div>
        <div>
          <SuggestionsPanel suggestions={data.suggestions} />
        </div>
      </div>
    </div>
  );
};

export default AnalysisDashboard;