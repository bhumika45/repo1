import React, { useState } from 'react';
import Header from './components/Header';
import UploadSection from './components/UploadSection';
import AnalysisDashboard from './components/AnalysisDashboard';
import Footer from './components/Footer';

export interface AnalysisData {
  overallScore: number;
  sections: {
    skills: { score: number; matches: string[]; missing: string[]; };
    experience: { score: number; relevantYears: number; matchingRoles: string[]; };
    education: { score: number; relevantDegrees: string[]; certifications: string[]; };
    keywords: { score: number; matched: number; total: number; missing: string[]; };
  };
  suggestions: string[];
  atsCompatibility: number;
}

function App() {
  const [analysisData, setAnalysisData] = useState<AnalysisData | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleAnalysis = async (resumeFile: File | null, linkedinData: string, jobDescription: string) => {
    setIsAnalyzing(true);
    
    // Simulate analysis process
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock analysis results
    const mockAnalysis: AnalysisData = {
      overallScore: 78,
      sections: {
        skills: {
          score: 85,
          matches: ['JavaScript', 'React', 'Node.js', 'Python', 'SQL'],
          missing: ['AWS', 'Docker', 'Kubernetes', 'GraphQL']
        },
        experience: {
          score: 72,
          relevantYears: 3.5,
          matchingRoles: ['Frontend Developer', 'Full Stack Engineer']
        },
        education: {
          score: 80,
          relevantDegrees: ['Computer Science'],
          certifications: ['AWS Certified Developer']
        },
        keywords: {
          score: 65,
          matched: 23,
          total: 35,
          missing: ['microservices', 'agile methodology', 'CI/CD', 'test-driven development']
        }
      },
      suggestions: [
        'Add cloud computing skills (AWS, Azure) to match job requirements',
        'Include more specific metrics and achievements in your experience section',
        'Incorporate missing keywords like "microservices" and "agile methodology"',
        'Consider adding relevant certifications in cloud technologies',
        'Quantify your impact with specific numbers and percentages',
        'Optimize resume format for better ATS compatibility'
      ],
      atsCompatibility: 73
    };
    
    setAnalysisData(mockAnalysis);
    setIsAnalyzing(false);
  };

  const handleReset = () => {
    setAnalysisData(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        {!analysisData ? (
          <UploadSection onAnalyze={handleAnalysis} isAnalyzing={isAnalyzing} />
        ) : (
          <AnalysisDashboard data={analysisData} onReset={handleReset} />
        )}
      </main>
      
      <Footer />
    </div>
  );
}

export default App;